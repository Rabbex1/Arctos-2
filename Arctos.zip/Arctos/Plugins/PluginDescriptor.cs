﻿namespace Arctos.Plugins;

public sealed class PluginDescriptor
{
    public required string AssemblyPath { get; init; }       // Full DLL path
    public required string TypeName { get; init; }           // Full class name (namespace + type)
    public required string Name { get; init; }               // From [PluginMetadata]
    public string? Description { get; init; }                // From [PluginMetadata]
    public string? Version { get; init; }                    // From [PluginMetadata]
    public bool IsLoaded { get; set; } = false;              // For UI use

    public override string ToString() => $"{Name} ({Version}) — {TypeName}";
}